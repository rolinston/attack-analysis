/*
 * Copyright (C) 2000 Lennert Buytenhek
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/fcntl.h>
#include <sys/ioctl.h>

#include "libbridge.h"
#include "libbridge_private.h"


int br_add_bridge(const char *brname)
{
	int ret;

#ifdef SIOCBRADDBR
	ret = ioctl(br_socket_fd, SIOCBRADDBR, brname);
	if (ret < 0)
#endif
	{
		char _br[IFNAMSIZ];
		unsigned long arg[3] 
			= { BRCTL_ADD_BRIDGE, (unsigned long) _br };

		strncpy(_br, brname, IFNAMSIZ);
		ret = ioctl(br_socket_fd, SIOCSIFBR, arg);
	} 

	return ret < 0 ? errno : 0;
}

int br_del_bridge(const char *brname)
{
	int ret;

#ifdef SIOCBRDELBR	
	ret = ioctl(br_socket_fd, SIOCBRDELBR, brname);
	if (ret < 0)
#endif
	{
		char _br[IFNAMSIZ];
		unsigned long arg[3] 
			= { BRCTL_DEL_BRIDGE, (unsigned long) _br };

		strncpy(_br, brname, IFNAMSIZ);
		ret = ioctl(br_socket_fd, SIOCSIFBR, arg);
	} 
	return  ret < 0 ? errno : 0;
}

int br_add_interface(const char *bridge, const char *dev)
{
	struct ifreq ifr;
	int err;
	int ifindex = if_nametoindex(dev);

	if (ifindex == 0) 
		return ENODEV;
	
	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
#ifdef SIOCBRADDIF
	ifr.ifr_ifindex = ifindex;
	err = ioctl(br_socket_fd, SIOCBRADDIF, &ifr);
	if (err < 0)
#endif
	{
		unsigned long args[4] = { BRCTL_ADD_IF, ifindex, 0, 0 };
					  
		ifr.ifr_data = (char *) args;
		err = ioctl(br_socket_fd, SIOCDEVPRIVATE, &ifr);
	}

	return err < 0 ? errno : 0;
}

int br_del_interface(const char *bridge, const char *dev)
{
	struct ifreq ifr;
	int err;
	int ifindex = if_nametoindex(dev);

	if (ifindex == 0) 
		return ENODEV;
	
	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
#ifdef SIOCBRDELIF
	ifr.ifr_ifindex = ifindex;
	err = ioctl(br_socket_fd, SIOCBRDELIF, &ifr);
	if (err < 0)
#endif		
	{
		unsigned long args[4] = { BRCTL_DEL_IF, ifindex, 0, 0 };
					  
		ifr.ifr_data = (char *) args;
		err = ioctl(br_socket_fd, SIOCDEVPRIVATE, &ifr);
	}

	return err < 0 ? errno : 0;
}
/*start bridge bind, z37589, 20070814*/
#ifdef SUPPORT_BRIDGE_BIND
int br_add_group(const char *bridge, const char *groupid)
{
	struct ifreq ifr;
	int err;
	char *p = groupid;
	
	while('\0' != *p)
    {
        if( !isdigit(*p) )
        {
            return EINVAL;
	    }
    	p++;
    }
		
	unsigned long args[4] = { BRCTL_ADD_GROUP, atol(groupid), 0, 0 };
	
    if(DEBUG_VBR)
        printf("BRGROUP: add group %s, br %s, file %s, line %d\n", 
                 groupid, bridge, __FILE__, __LINE__);
        
	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
	ifr.ifr_data = (char *) args;
	err = ioctl(br_socket_fd, SIOCDEVPRIVATE, &ifr);

	return err < 0 ? errno : 0;
}
int br_del_group(const char *bridge, const char *groupid)
{
	struct ifreq ifr;
	int err;
	char *p = groupid;
	
	while('\0' != *p)
    {
        if( !isdigit(*p) )
        {
            return EINVAL;
	    }
    	p++;
    }
	
	unsigned long args[4] = { BRCTL_DEL_GROUP, atol(groupid), 0, 0 };

    if(DEBUG_VBR)
        printf("BRGROUP: del group %d, br %s, file %s, line %d\n",
               groupid, bridge, __FILE__, __LINE__);

	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
	ifr.ifr_data = (char *) args;
	err = ioctl(br_socket_fd, SIOCDEVPRIVATE, &ifr);

	return err < 0 ? errno : 0;
}
int br_add_groupports(const char *bridge, unsigned short groupid, unsigned short pts_mask)
{
	struct ifreq ifr;
	int err;
	unsigned long args[4] = { BRCTL_ADD_GROUP_PORTS, (unsigned long)groupid, (unsigned short)pts_mask, 0 };

    if(DEBUG_VBR)
        printf("BRGROUP: add group ports, group %d, br %s, ports mask 0x%x, file %s, line %d\n", 
                groupid, bridge, pts_mask, __FILE__, __LINE__);

	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
	ifr.ifr_data = (char *) args;
	err = ioctl(br_socket_fd, SIOCDEVPRIVATE, &ifr);

	return err < 0 ? errno : 0;
}
int br_del_groupports(const char *bridge, unsigned short groupid, unsigned short pts_mask)
{
	struct ifreq ifr;
	int err;
	unsigned long args[4] = { BRCTL_DEL_GROUP_PORTS, (unsigned long)groupid, (unsigned short)pts_mask, 0 };
	
	if(DEBUG_VBR)
        printf("BRGROUP: del group ports, group %d, br %s, ports mask 0x%x, file %s, line %d\n", 
                 groupid, bridge, pts_mask, __FILE__, __LINE__);

	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
	ifr.ifr_data = (char *) args;
	err = ioctl(br_socket_fd, SIOCDEVPRIVATE, &ifr);

	return err < 0 ? errno : 0;
}

int br_set_groupflag(const char *bridge, const char *groupflag)
{
    struct ifreq ifr;
	int err;
	char *p ;
	
	for(p = groupflag; '\0' != *p; p++)
    {
        if( !isdigit(*p) )
        {
            return EINVAL;
	    }
    }
	
	unsigned long args[4] = { BRCTL_SET_GROUPFLAG,  atol(groupflag), 0, 0 };
	
    if(DEBUG_VBR)
        printf("BRGROUP: set bridge groupflag %s, br %s, file %s, line %d\n", 
                 groupflag, bridge, __FILE__, __LINE__);
        
	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
	ifr.ifr_data = (char *) args;
	err = ioctl(br_socket_fd, SIOCDEVPRIVATE, &ifr);

	return err < 0 ? errno : 0;
}

int br_set_groupmacln(const char *bridge, const char *groupid, const char *enable)
{
    struct ifreq ifr;
	int err;
	char *p ;
	
	for(p = groupid; '\0' != *p; p++)
    {
        if( !isdigit(*p) )
        {
            return EINVAL;
	    }
    }

	for(p = enable; '\0' != *p; p++)
    {
        if( !isdigit(*p) )
        {
            return EINVAL;
	    }
    }
	
	unsigned long args[4] = { BRCTL_SET_GROUPMACLN,  atol(groupid), atol(enable), 0 };
	
    if(DEBUG_VBR)
        printf("BRGROUP: set group %s mac learning %s, br %s, file %s, line %d\n", 
                 groupid, enable, bridge, __FILE__, __LINE__);
        
	strncpy(ifr.ifr_name, bridge, IFNAMSIZ);
	ifr.ifr_data = (char *) args;
	err = ioctl(br_socket_fd, SIOCDEVPRIVATE, &ifr);

	return err < 0 ? errno : 0;
}
#endif
/*end bridge bind, z37589, 20070814*/
