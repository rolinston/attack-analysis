/* vi: set sw=4 ts=4: */
/*
 * ftpget
 *
 * Mini implementation of FTP to retrieve a remote file.
 *
 * Copyright (C) 2002 Jeff Angielski, The PTR Group <jeff@theptrgroup.com>
 * Copyright (C) 2002 Glenn McGrath
 *
 * Based on wget.c by Chip Rosenthal Covad Communications
 * <chip@laserlink.net>
 *
 * Licensed under GPLv2 or later, see file LICENSE in this tarball for details.
 */

#include <getopt.h>
#include "libbb.h"
#include "atpcommon.h"

typedef struct ftp_host_info_s {
	const char *user;
	const char *password;
	struct len_and_sockaddr *lsa;
} ftp_host_info_t;

static smallint verbose_flag;
/*Start of Maintain 2008-3-1 14:28 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#if 0
#else
static FILE *control_stream_in = NULL;
#endif
/*End of Maintain 2008-3-1 14:28 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/

static void ftp_die(const char *msg, const char *remote) ATTRIBUTE_NORETURN;
static void ftp_die(const char *msg, const char *remote)
{
	/* Guard against garbage from remote server */
	const char *cp = remote;
	while (*cp >= ' ' && *cp < '\x7f') cp++;
	bb_error_msg_and_die("unexpected server response%s%s: %.*s",
			msg ? " to " : "", msg ? msg : "",
			(int)(cp - remote), remote);
}


static int ftpcmd(const char *s1, const char *s2, FILE *stream, char *buf)
{
	unsigned n;
	if (verbose_flag) {
		bb_error_msg("cmd %s %s", s1, s2);
	}

    /*Start of MNT 2008-10-13 14:40 for ���䳬ʱ��� by z65940*/
    g_TimeoutCnt = 20;  // ÿ������ĳ�ʱ���
    /*End of MNT 2008-10-13 14:40 for by z65940*/

	if (s1) {
		if (s2) {
			fprintf(stream, "%s %s\r\n", s1, s2);
		} else {
			fprintf(stream, "%s\r\n", s1);
		}
        /*Start of Maintain 2008-3-1 15:47 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
        fflush(stream);
        /*End of Maintain 2008-3-1 15:47 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
	}
	do {
		char *buf_ptr;

        /*Start of Maintain 2008-3-1 15:26 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
    #if 0
		if (fgets(buf, 510, stream) == NULL) {
    #else
		if (fgets(buf, 510, control_stream_in) == NULL) {
    #endif
        /*End of Maintain 2008-3-1 15:26 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
			bb_perror_msg_and_die("fgets");
		}
		buf_ptr = strstr(buf, "\r\n");
		if (buf_ptr) {
			*buf_ptr = '\0';
		}
	} while (!isdigit(buf[0]) || buf[3] != ' ');

	buf[3] = '\0';
	n = xatou(buf);
	buf[3] = ' ';

    /*Start of MNT 2008-10-13 14:40 for ���䳬ʱ��� by z65940*/
    g_TimeoutCnt = -1;  // ÿ������ĳ�ʱ���
    /*End of MNT 2008-10-13 14:40 for by z65940*/

	return n;
}

static int xconnect_ftpdata(ftp_host_info_t *server, char *buf)
{
	char *buf_ptr;
	unsigned short port_num;

	/* Response is "NNN garbageN1,N2,N3,N4,P1,P2[)garbage]
	 * Server's IP is N1.N2.N3.N4 (we ignore it)
	 * Server's port for data connection is P1*256+P2 */
	buf_ptr = strrchr(buf, ')');
	if (buf_ptr) *buf_ptr = '\0';

	buf_ptr = strrchr(buf, ',');
	*buf_ptr = '\0';
	port_num = xatoul_range(buf_ptr + 1, 0, 255);

	buf_ptr = strrchr(buf, ',');
	*buf_ptr = '\0';
	port_num += xatoul_range(buf_ptr + 1, 0, 255) * 256;

	set_nport(server->lsa, htons(port_num));
    /*Start of Maintain 2008-3-1 16:11 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#if 0
	return xconnect_stream(server->lsa);
#else
	return xbind_connect(server->lsa, g_pcLocalIP);
#endif
    /*End of Maintain 2008-3-1 16:11 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
}

/*Start of ά�������� 2008-4-15 16:55 for �޸�ftp֧��Զ��·�� by handy*/
#if 0
static FILE *ftp_login(ftp_host_info_t *server)
#else
static FILE *ftp_login(ftp_host_info_t *server, char *pcRemotePath)
#endif
/*End of ά�������� 2008-4-15 16:55 for �޸�ftp֧��Զ��·�� by handy*/
{
	FILE *control_stream;
	char buf[512];
/*Start of Maintain 2008-3-1 15:21 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
    int  sock;
/*End of Maintain 2008-3-1 15:21 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/

/*Start of ά�������� 2008-4-15 16:56 for �޸�ftp֧��Զ��·�� by handy*/
    char *pcName;
/*End of ά�������� 2008-4-15 16:56 for �޸�ftp֧��Զ��·�� by handy*/

	/* Connect to the command socket */
    /*Start of Maintain 2008-3-1 15:5 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#if 0
	control_stream = fdopen(xconnect_stream(server->lsa), "r+");
	if (control_stream == NULL) {
		/* fdopen failed - extremely unlikely */
		bb_perror_nomsg_and_die();
	}
#else
    // If error, default to be connection timeout
    xfunc_error_retval = ATP_TRANS_TIMEOUT;
    // This function will bind if g_pcLocalIP is not NULL
    sock = xbind_connect(server->lsa, g_pcLocalIP);
    // Some system can not read and write one socket at the same time
	control_stream = fdopen(sock, "w");
    control_stream_in = fdopen(sock, "r");
	if ((control_stream == NULL) || (control_stream_in == NULL)){
		/* fdopen failed - extremely unlikely */
		bb_perror_nomsg_and_die();
	}

    // Restore to system error
    xfunc_error_retval = ATP_TRANS_SYS_ERR;
#endif
    /*End of Maintain 2008-3-1 15:5 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/

	if (ftpcmd(NULL, NULL, control_stream, buf) != 220) {
		ftp_die(NULL, buf);
	}

	/*  Login to the server */
	switch (ftpcmd("USER", server->user, control_stream, buf)) {
	case 230:
		break;
	case 331:
		if (ftpcmd("PASS", server->password, control_stream, buf) != 230) {
            /*Start of Maintain 2008-3-1 16:25 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
            xfunc_error_retval = ATP_TRANS_AUTH_ERR;
            /*End of Maintain 2008-3-1 16:25 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
			ftp_die("PASS", buf);
		}
		break;
	default:
		ftp_die("USER", buf);
	}

	ftpcmd("TYPE I", NULL, control_stream, buf);

    /*Start of ά�������� 2008-4-15 16:56 for �޸�ftp֧��Զ��·�� by handy*/
    pcName = strrchr(pcRemotePath, '/');
    if (NULL != pcName)
    {
        (*pcName) = '\0';
    }
    if ((NULL != pcName) && ('\0' != pcRemotePath[0]))
    {
        ftpcmd("CWD", pcRemotePath, control_stream, buf);
    }
    else
    {
        ftpcmd("CWD", "/", control_stream, buf);
    }
    if (NULL != pcName)     // �ָ����һ��Ŀ¼��/
    {
        (*pcName) = '/';
    }
    /*End of ά�������� 2008-4-15 16:56 for �޸�ftp֧��Զ��·�� by handy*/

	return control_stream;
}

#if !ENABLE_ATP_FTPGET
int ftp_receive(ftp_host_info_t *server, FILE *control_stream,
		const char *local_path, const char *server_path);
#else
static
int ftp_receive(ftp_host_info_t *server, FILE *control_stream,
		const char *local_path, const char *server_path)
{
	char buf[512];
/* I think 'filesize' usage here is bogus. Let's see... */
	off_t filesize = -1;
//#define filesize ((off_t)-1)
	int fd_data;
#if ENABLE_FEATURE_ATP_FTP_ZIP
	gzFile fd_local = NULL;
#else
    int fd_local = -1;
#endif
    int transsize;

	/* Connect to the data socket */
	if (ftpcmd("PASV", NULL, control_stream, buf) != 227) {
		ftp_die("PASV", buf);
	}
	fd_data = xconnect_ftpdata(server, buf);

	if (ftpcmd("SIZE", server_path, control_stream, buf) == 213) {
		filesize = BB_STRTOOFF(buf + 4, NULL, 10);
		if (errno || filesize < 0)
			ftp_die("SIZE", buf);
	}
    if (filesize < g_lTransEnd) {
        xfunc_error_retval = ATP_TRANS_FILE_ERR;
        ftp_die("SIZE", buf);
    }
    transsize = filesize;

	if (g_lTransEnd >= 0) {
        // ���ָ���˴�����ʼƫ��������ָ��õ�ַ
        if (NULL != g_pcTransBegin) {
    		sprintf(buf, "REST %s", g_pcTransBegin);

            transsize = atoi(g_pcTransBegin);

            // ���û��ָ�����س��ȣ������غ��������ֽ�
            if (NULL == g_pcTransEnd) {
                transsize = filesize - transsize;
                filesize = -1;
            }
            else if (0 == g_lTransEnd) {
                g_lTransEnd = transsize + 1;
                transsize = 1;
            }
            else {
                // ���¼��㳤��
                g_lTransEnd -= transsize;
                g_lTransEnd += 1;
                transsize = g_lTransEnd;
            }
        } else {
            // ���û��ָ����ʼƫ������������ĩβ��g_pcTransBegin�ֽ�
            sprintf(buf, "REST %d", (int)(filesize - (off_t)g_lTransEnd));
            transsize = (int)g_lTransEnd;
        }
        filesize = transsize;

        if (ftpcmd(buf, NULL, control_stream, buf) != 350) {
			ftp_die("REST", buf);
		}
	}
    else {  // û�зֶδ��䣬�����������ֽ�
        // �ж��ļ���С�Ƿ����
        filesize = -1;
    }

    // ��ʹ��ѹ��ʱ������ֱ���ж��ļ��Ƿ����
    if ((g_lMaxTrans > 0) && (transsize > g_lMaxTrans)) {
        xfunc_error_retval = ATP_TRANS_FILE_ERR;
        bb_error_msg_and_die("File too big\n");
    }

	if (ftpcmd("RETR", server_path, control_stream, buf) > 150) {
        xfunc_error_retval = ATP_TRANS_FILE_ERR;
		ftp_die("RETR", buf);
	}

	/* only make a local file if we know that one exists on the remote server */
	if (fd_local <= 0) {
        xfunc_error_retval = ATP_TRANS_FILE_ERR;
    #if ENABLE_FEATURE_ATP_FTP_ZIP
        if (g_bCompress) {
            fd_local = gzopen(local_path, "wb9");
        } else {
            fd_local = (gzFile)xopen(local_path, O_CREAT | O_TRUNC | O_WRONLY);
        }
        if ((int)fd_local <= 0) {
            bb_error_msg_and_die("Open file err\n");
        }
    #else
		fd_local = xopen(local_path, O_CREAT | O_TRUNC | O_WRONLY);
    #endif
        xfunc_error_retval = ATP_TRANS_SYS_ERR;
	}

	/* Copy the file */
#if ENABLE_FEATURE_ATP_FTP_ZIP
    if (g_bCompress) {
        if (-1 == atp_copy_to_zipfile(fd_data, fd_local, filesize)) {
            return ATP_TRANS_SYS_ERR;
        }
        gzclose(fd_local);
        if (-1 != filesize) {
            // Abort the current transfer now
            ftpcmd("ABOR", NULL, control_stream, buf);
        }
    } else {
        if (filesize != -1) {
            /*Start of MNT 2008-10-13 15:8 for ���䳬ʱ��� by z65940*/
        #if 0
    		if (bb_copyfd_size(fd_data, (int)fd_local, filesize) == -1)
        #else
    		if (atp_copy_fd_with_timeout(fd_data, (int)fd_local, filesize) == -1)
        #endif
            /*End of MNT 2008-10-13 15:8 by z65940*/
    			return ATP_TRANS_SYS_ERR;

            // Abort the current transfer now
            ftpcmd("ABOR", NULL, control_stream, buf);
    	} else {
            /*Start of MNT 2008-10-13 15:8 for ���䳬ʱ��� by z65940*/
        #if 0
    		if (bb_copyfd_eof(fd_data, (int)fd_local) == -1)
        #else
    		if (atp_copy_fd_with_timeout(fd_data, (int)fd_local, 0) == -1)
        #endif
            /*End of MNT 2008-10-13 15:8 by z65940*/
    			return ATP_TRANS_SYS_ERR;
    	}
        close((int)fd_local);
    }
#else
	if (filesize != -1) {
        /*Start of MNT 2008-10-13 15:9 for ���䳬ʱ��� by z65940*/
    #if 0
		if (bb_copyfd_size(fd_data, fd_local, filesize) == -1)
    #else
		if (atp_copy_fd_with_timeout(fd_data, fd_local, filesize) == -1)
    #endif
        /*End of MNT 2008-10-13 15:9 by z65940*/
			return ATP_TRANS_SYS_ERR;

        // Abort the current transfer now
        ftpcmd("ABOR", NULL, control_stream, buf);
	} else {
        /*Start of MNT 2008-10-13 15:9 for ���䳬ʱ��� by z65940*/
    #if 0
		if (bb_copyfd_eof(fd_data, fd_local) == -1)
    #else
		if (atp_copy_fd_with_timeout(fd_data, fd_local, 0) == -1)
    #endif
        /*End of MNT 2008-10-13 15:9 by z65940*/
			return ATP_TRANS_SYS_ERR;
	}
    close(fd_local);
#endif

	/* close it all down */
	close(fd_data);
    /*Start of MNT 2008-8-27 14:58 for ��WindowsServer 2003�Խ� by z65940*/
#if 0
	if (ftpcmd(NULL, NULL, control_stream, buf) != 226) {
#else
    transsize = ftpcmd(NULL, NULL, control_stream, buf);
	if ((transsize != 226) && (transsize != 225)) {
#endif
    /*End of MNT 2008-8-27 14:58 by z65940*/
		ftp_die(NULL, buf);
	}
	ftpcmd("QUIT", NULL, control_stream, buf);

	return EXIT_SUCCESS;
}
#endif

#if !CONFIG_ATP_FTPPUT
int ftp_send(ftp_host_info_t *server, FILE *control_stream,
		const char *local_path, const char *server_path);
#else
static
int ftp_send(ftp_host_info_t *server, FILE *control_stream,
		const char *local_path, const char *server_path)
{
	struct stat sbuf;
	char buf[512];
	int fd_data;
	int fd_local;
	int response;

	/*  Connect to the data socket */
	if (ftpcmd("PASV", NULL, control_stream, buf) != 227) {
		ftp_die("PASV", buf);
	}
	fd_data = xconnect_ftpdata(server, buf);

	/* get the local file */
	fd_local = STDIN_FILENO;
	if (NOT_LONE_DASH(local_path)) {
        xfunc_error_retval = ATP_TRANS_FILE_ERR;
		fd_local = xopen(local_path, O_RDONLY);
        xfunc_error_retval = ATP_TRANS_SYS_ERR;
		fstat(fd_local, &sbuf);

		sprintf(buf, "ALLO %"OFF_FMT"u", sbuf.st_size);
		response = ftpcmd(buf, NULL, control_stream, buf);
		switch (response) {
		case 200:
		case 202:
        /*start of HG_Support 2009.2.28 for ĳЩFTP Server��ʶ��ALLO���� by s00124929*/
        default:
			break;
#if 0
		default:
			close(fd_local);
			ftp_die("ALLO", buf);
			break;
#endif
        /*end of HG_Support 2009.2.28 for ĳЩFTP Server��ʶ��ALLO���� by s00124929*/
		}
	}
	response = ftpcmd("STOR", server_path, control_stream, buf);
	switch (response) {
	case 125:
	case 150:
		break;
	default:
		close(fd_local);
        xfunc_error_retval = ATP_TRANS_FILE_ERR;
		ftp_die("STOR", buf);
	}

	/* transfer the file  */
    /*Start of MNT 2008-10-13 15:9 for ���䳬ʱ��� by z65940*/
#if 0
	if (bb_copyfd_eof(fd_local, fd_data) == -1) {
		exit(ATP_TRANS_SYS_ERR);
	}
#else
	if (atp_copy_fd_with_timeout(fd_local, fd_data, 0) == -1) {
		exit(ATP_TRANS_SYS_ERR);
	}
#endif
    /*End of MNT 2008-10-13 15:9 by z65940*/

	/* close it all down */
	close(fd_data);
	if (ftpcmd(NULL, NULL, control_stream, buf) != 226) {
		ftp_die("close", buf);
	}
	ftpcmd("QUIT", NULL, control_stream, buf);

	return EXIT_SUCCESS;
}
#endif

/*Start of Maintain 2008-3-1 14:28 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#if 0
#define FTPGETPUT_OPT_CONTINUE	1
#define FTPGETPUT_OPT_VERBOSE	2
#define FTPGETPUT_OPT_USER	4
#define FTPGETPUT_OPT_PASSWORD	8
#define FTPGETPUT_OPT_PORT	16

#if ENABLE_FEATURE_FTPGETPUT_LONG_OPTIONS
static const char ftpgetput_longopts[] ALIGN1 =
	"continue\0" Required_argument "c"
	"verbose\0"  No_argument       "v"
	"username\0" Required_argument "u"
	"password\0" Required_argument "p"
	"port\0"     Required_argument "P"
	;
#endif
#else

#if ENABLE_FEATURE_ATP_FTPGETPUT_LONG_OPTIONS
static const char ftpgetput_longopts[] ALIGN1 =
	"continue\0" Required_argument "c"
	"verbose\0"  No_argument       "v"
	"username\0" Required_argument "u"
	"password\0" Required_argument "p"
	"port\0"     Required_argument "P"
	;
#endif
#endif
/*End of Maintain 2008-3-1 14:28 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/

int ftpget_main(int argc, char **argv) MAIN_EXTERNALLY_VISIBLE;
int ftpget_main(int argc, char **argv)
{
	/* content-length of the file */
	unsigned opt;
	const char *port = "ftp";
	/* socket to ftp server */
	FILE *control_stream;
	/* continue previous transfer (-c) */
	ftp_host_info_t *server;
    /*Start of Maintain 2008-3-1 14:26 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
    char *pcLocalFile;
    char *pcRemoteFile;
    char *pcRemoteFileName;
    char *pcRemoteIP;
    /*End of Maintain 2008-3-1 14:26 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
    const char *pcMaxTrans      = NULL;

#if ENABLE_ATP_FTPGET && !CONFIG_ATP_FTPPUT
# define ftp_action ftp_send
#elif ENABLE_ATP_FTPGET && !CONFIG_ATP_FTPPUT
# define ftp_action ftp_receive
#else
	int (*ftp_action)(ftp_host_info_t *, FILE *, const char *, const char *) = ftp_send;
	/* Check to see if the command is ftpget or ftput */
	if (applet_name[3] == 'g') {
		ftp_action = ftp_receive;
	}
#endif

    /*Start of MNT 2008-10-13 14:39 for ���䳬ʱ��� by z65940*/
    g_TimeoutCnt = -1;
    atp_setup_alarm();
    /*End of MNT 2008-10-13 14:39 for by z65940*/

	/* Set default values */
	server = xmalloc(sizeof(*server));
	server->user = "anonymous";
	server->password = "busybox@";

    g_pcLocalIP     = NULL;
    g_pcTransBegin  = NULL;
    g_pcTransEnd    = NULL;
    g_lTransEnd     = -1;
    g_lMaxTrans     = -1;
#if ENABLE_FEATURE_ATP_FTP_ZIP
    g_bCompress     = 0;
    #define ZIP_OPT_CHAR    "c"
#else
    #define ZIP_OPT_CHAR
#endif

	/*
	 * Decipher the command line
	 */
#if ENABLE_FEATURE_ATP_FTPGETPUT_LONG_OPTIONS
    /*Start of Maintain 2008-3-1 12:14 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#if 0
	applet_long_options = ftpgetput_longopts;
#else
	applet_long_options = bb_transtool_long_options;
#endif
    /*End of Maintain 2008-3-1 12:14 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#endif
    /*Start of Maintain 2008-3-1 12:16 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#if 0
    opt_complementary = "=3"; /* must have 3 params */
	opt = getopt32(argv, "cvu:p:P:", &server->user, &server->password, &port);
#else
    // Default error code
    xfunc_error_retval = ATP_TRANS_SYS_ERR;
    opt_complementary = "=1"; /* must have 1 params */
	//opt = getopt32(argv, "cvu:p:P:", &server->user, &server->password, &port);
    opt = getopt32(argv, "gsvu:p:r:l:P:B:A:b:e:m:"ZIP_OPT_CHAR,
                            &server->user,
                            &server->password,
                            &pcRemoteFile,
                            &pcLocalFile,
                            &port,
                            &g_pcLocalIP,
                            &pcRemoteIP,
                            &g_pcTransBegin,
                            &g_pcTransEnd,
                            &pcMaxTrans);
#endif
#undef ZIP_OPT_CHAR
    /*End of Maintain 2008-3-1 12:16 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
	argv += optind;

#if ENABLE_FEATURE_ATP_FTP_ZIP
    if (opt & TRANS_TOOL_OPT_ZIP) {
        g_bCompress = 1;
    }
#endif

    if (NULL != pcMaxTrans)
    {
        g_lMaxTrans = atoi(pcMaxTrans);
    }

    if (NULL == pcLocalFile) {
        bb_show_usage();
    }

    // �����س���
    if (NULL != g_pcTransEnd) {
        // ֻ��Ϊ����
        g_lTransEnd = atoi(g_pcTransEnd);
        if (g_lTransEnd <= 0)
                bb_show_usage();

        // ��������ʼλ�ã���������ؽ���λ��
        if (NULL != g_pcTransBegin) {
            // ����ƫ����
            g_lTransEnd +=  atoi(g_pcTransBegin);
            g_lTransEnd -= 1;
        }
    }
    // û�����س���
    else {
        // �����ؿ�ʼλ�ã�û�����س���
        if (NULL != g_pcTransBegin) {   // Download until end
            g_lTransEnd = 0;
        }
    }

	/* Process the non-option command line arguments */
	if (opt & TRANS_TOOL_OPT_VERBOSE) {
		verbose_flag = 1;
	}

	/* We want to do exactly _one_ DNS lookup, since some
	 * sites (i.e. ftp.us.debian.org) use round-robin DNS
	 * and we want to connect to only one IP... */
    /*Start of Maintain 2008-3-1 14:58 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#if 0
	server->lsa = xhost2sockaddr(argv[0], bb_lookup_port(port, "tcp", 21));
#else
    ftp_action = ftp_send;  // Upload
    if (opt & TRANS_TOOL_OPT_DOWNLOAD) {
		ftp_action = ftp_receive;
	}
    if (!(opt & TRANS_TOOL_OPT_REMOTEIP)) {
		// User has not resolved the host, we need to use host to resolve name
		pcRemoteIP = argv[0];
	}
    server->lsa = xhost2sockaddr(pcRemoteIP, bb_lookup_port(port, "tcp", 21));
#endif
    /*End of Maintain 2008-3-1 14:58 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
	if (verbose_flag) {
		printf("Connecting to %s (%s)\n", argv[0],
			xmalloc_sockaddr2dotted(&server->lsa->sa));
	}

	/*  Connect/Setup/Configure the FTP session */
    /*Start of ά�������� 2008-4-15 16:55 for �޸�ftp֧��Զ��·�� by handy*/
#if 0
    control_stream = ftp_login(server);
#else
    control_stream   = ftp_login(server, pcRemoteFile);
    pcRemoteFileName = strrchr(pcRemoteFile, '/');
    if (NULL != pcRemoteFileName)
    {
        pcRemoteFile = (pcRemoteFileName + 1);
    }
    // ���Զ���ļ����ǿմ�����ʹ�ñ��ص��ļ���
    if ((NULL == pcRemoteFile) || ('\0' == (*pcRemoteFile))) {
        pcRemoteFile = strrchr(pcLocalFile, '/');
        if (NULL != pcRemoteFile) {
            pcRemoteFile += 1;
        } else {
            pcRemoteFile = pcLocalFile;
        }
    }
#endif
    /*End of ά�������� 2008-4-15 16:55 for �޸�ftp֧��Զ��·�� by handy*/


    /*Start of Maintain 2008-3-1 14:49 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
#if 0
	return ftp_action(server, control_stream, argv[1], argv[2]);
#else
    // Default return error code
    xfunc_error_retval = ATP_TRANS_SYS_ERR;
	return ftp_action(server, control_stream, pcLocalFile, pcRemoteFile);
#endif
    /*End of Maintain 2008-3-1 14:49 for �޸�Busybox�еĴ��乤�ߣ�����cwmp�������� by z65940*/
}
