#ifndef __ATP_COMMON_H__
#define __ATP_COMMON_H__

#include "platform.h"

#if ENABLE_FEATURE_ATP_WGET_ZIP || ENABLE_FEATURE_ATP_FTP_ZIP || ENABLE_FEATURE_ATP_TFTP_ZIP || ENABLE_FEATURE_ATP_MCAST_ZIP
typedef void * gzFile;

extern gzFile gzopen(const char *path, const char *mode);
extern int gzwrite(gzFile file, const void *buf, unsigned int len);
extern int gzclose(gzFile file);

#endif

/* ftpget ftpput tftp wget���乤�ߵķ����� */
#define ATP_TRANS_OK                (0)
#define ATP_TRANS_TIMEOUT           (0xF1)
#define ATP_TRANS_FILE_ERR          (0xF2)
#define ATP_TRANS_SYS_ERR           (0xF3)
#define ATP_TRANS_AUTH_ERR          (0xF4)

/* ftpget ftpput tftp wget���乤�ߵ�������ѡ�� */
#define TRANS_TOOL_OPT_DOWNLOAD	    1
#define TRANS_TOOL_OPT_UPLOAD	    2
#define TRANS_TOOL_OPT_VERBOSE	    4
#define TRANS_TOOL_OPT_USER	        8
#define TRANS_TOOL_OPT_PASSWORD	    16
#define TRANS_TOOL_OPT_LOCALPATH	32
#define TRANS_TOOL_OPT_REMOTEPATH	64
#define TRANS_TOOL_OPT_REMOTEPORT	128
#define TRANS_TOOL_OPT_BINDIP       256
#define TRANS_TOOL_OPT_REMOTEIP     512
// 1024,2048,4096
#define TRANS_TOOL_OPT_ZIP	        8192

#if ENABLE_GETOPT_LONG
/* ftp wget��tftp���乤�ߵ��������÷�˵�� */
extern const char bb_transtool_long_options[];
#endif

#if 1
// ʹ��ȫ���ڴ棬���ӽ�ʡ�ڴ�
struct atp_trans_globals {
	int g_lTransEnd;            // �������λ��
	int g_lMaxTrans;            // �����ļ�����С
    const char *g_pcLocalIP;    // ���ذ�IP
    const char *g_pcTransBegin; // ���俪ʼ��ַ
    const char *g_pcTransEnd;   // ���������ַ

    int         bCompress;

    unsigned int g_ulTotalLen;
    int mcast_seq_num;
    int mcast_len;
    unsigned char *mcast_buf;

    int         timout_cnt;
};

#define HANDY (*(struct atp_trans_globals*)&bb_common_bufsiz1)

#define g_pcLocalIP     (HANDY.g_pcLocalIP    )
#define g_pcTransBegin  (HANDY.g_pcTransBegin )
#define g_pcTransEnd    (HANDY.g_pcTransEnd   )
#define g_lTransEnd     (HANDY.g_lTransEnd    )
#define g_lMaxTrans     (HANDY.g_lMaxTrans    )

#define g_ulTotalLen    (HANDY.g_ulTotalLen   )
#define g_lMcastSeqNum  (HANDY.mcast_seq_num  )
#define g_lMcastLen     (HANDY.mcast_len      )
#define g_pucMcastBuf   (HANDY.mcast_buf      )
#define g_bCompress     (HANDY.bCompress      )

#define g_TimeoutCnt    (HANDY.timout_cnt     )

#else

extern const char *g_pcLocalIP;
extern const char *g_pcTransBegin;
extern int g_lTransEnd;
extern int g_lMaxTrans;
#endif

int xbind_connect(const len_and_sockaddr *lsa, const char *ip);

#if ENABLE_FEATURE_ATP_WGET_ZIP || ENABLE_FEATURE_ATP_FTP_ZIP || ENABLE_FEATURE_ATP_MCAST_ZIP
void atp_zip_write(gzFile fd, const void *buf, size_t count);
#define atp_write atp_zip_write

int atp_copy_to_zipfile(int src_fd, gzFile dst_file, int filesize);
#else
#define atp_write xwrite
#endif

/*Start of MNT 2008-10-13 14:36 for ���䳬ʱ��� by z65940*/
#define ATP_CONNECT_TIMEOUT_D   (20)    // 20�����ӳ�ʱ
#define ATP_PACK_TIMEOUT_D      (30)    // 30��û���յ�������ʱ

void atp_setup_alarm();
off_t atp_copy_fd_with_timeout(int src_fd, int dst_fd, off_t size);
/*End of MNT 2008-10-13 14:36 for by z65940*/

#endif

