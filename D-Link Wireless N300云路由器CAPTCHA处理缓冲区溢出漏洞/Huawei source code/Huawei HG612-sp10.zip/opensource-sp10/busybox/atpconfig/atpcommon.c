#include "libbb.h"
#include "atpcommon.h"

#if ENABLE_GETOPT_LONG
const char bb_transtool_long_options[] ALIGN1 =
    "download\0" No_argument        "g"
	"upload\0"   No_argument        "s"
	"verbose\0"  No_argument        "v"
	"username\0" Required_argument  "u"
	"password\0" Required_argument  "p"
	"local\0"    Required_argument  "l"
	"remote\0"   Required_argument  "r"
	"port\0"     Required_argument  "P"
	"bind\0"     Required_argument  "B"
	"addr\0"     Required_argument  "A"
    ;
#endif

#if 0
const char *g_pcLocalIP     = NULL;
const char *g_pcTransBegin  = NULL;
int        g_lTransEnd      = -1;
int        g_lMaxTrans      = -1;
#endif

int xbind_connect(const len_and_sockaddr *lsa, const char *ip)
{
	int fd;
    /*Start of MNT 2008-10-13 14:40 for ���䳬ʱ��� by z65940*/
    g_TimeoutCnt = ATP_CONNECT_TIMEOUT_D;  // ÿ������ĳ�ʱ���
    /*End of MNT 2008-10-13 14:40 for by z65940*/

    if (NULL == ip)
    {
        // No bind, the same as xconnect_stream
        fd = xconnect_stream(lsa);
        /*Start of MNT 2008-10-13 14:40 for ���䳬ʱ��� by z65940*/
        g_TimeoutCnt = -1;
        /*End of MNT 2008-10-13 14:40 for by z65940*/
        return fd;
    }

    // Bind to specified local interface
    //fd = create_and_bind_stream_or_die(ip, get_nport(&(lsa->sa)));
    fd = create_and_bind_stream_or_die(ip, 0);
    xconnect(fd, &(lsa->sa), lsa->len);
    /*Start of MNT 2008-10-13 14:40 for ���䳬ʱ��� by z65940*/
    g_TimeoutCnt = -1;
    /*End of MNT 2008-10-13 14:40 for by z65940*/
	return fd;
}

#if ENABLE_FEATURE_ATP_WGET_ZIP || ENABLE_FEATURE_ATP_FTP_ZIP || ENABLE_FEATURE_ATP_MCAST_ZIP
void atp_zip_write(gzFile fd, const void *buf, size_t count)
{
    int bytesWrite;

    if (!g_bCompress) {
        xwrite((int)fd, buf, count);
        return;
    }

    // Add to zip file
    bytesWrite = gzwrite(fd, buf, count);
    if ((size_t)bytesWrite != count) {
        bb_error_msg_and_die("zip write");
    }
}

int atp_copy_to_zipfile(int src_fd, gzFile dst_file, int filesize)
{
    int status = -1;
	off_t total = 0;
#if CONFIG_FEATURE_COPYBUF_KB <= 4
	char buffer[CONFIG_FEATURE_COPYBUF_KB * 1024];
	int buffer_size = sizeof(buffer);
#else
	char *buffer;
	int buffer_size;

	/* We want page-aligned buffer, just in case kernel is clever
	 * and can do page-aligned io more efficiently */
	buffer = mmap(NULL, CONFIG_FEATURE_COPYBUF_KB * 1024,
			PROT_READ | PROT_WRITE,
			MAP_PRIVATE | MAP_ANON,
			/* ignored: */ -1, 0);
	buffer_size = CONFIG_FEATURE_COPYBUF_KB * 1024;
	if (buffer == MAP_FAILED) {
		buffer = alloca(4 * 1024);
		buffer_size = 4 * 1024;
	}
#endif

	if ((src_fd < 0) || (NULL == dst_file))
		goto out;

    if (filesize <= 0) {
        filesize = buffer_size;
        status = 1; /* copy until eof */
    }

	while (1) {
		ssize_t rd;

        /*Start of MNT 2008-10-13 14:40 for ���䳬ʱ��� by z65940*/
        g_TimeoutCnt = ATP_PACK_TIMEOUT_D;  // ��ȡÿ�����45��
        /*End of MNT 2008-10-13 14:40 for by z65940*/
		rd = safe_read(src_fd, buffer, filesize > buffer_size ? buffer_size : filesize);
        /*Start of MNT 2008-10-13 14:40 for ���䳬ʱ��� by z65940*/
        g_TimeoutCnt = -1;
        /*End of MNT 2008-10-13 14:40 for by z65940*/

		if (!rd) { /* eof - all done */
			status = 0;
			break;
		}
		if (rd < 0) {
			bb_perror_msg(bb_msg_read_error);
			break;
		}
		atp_zip_write(dst_file, (const void *)buffer, rd);
		total += rd;
		if (status < 0) { /* if we aren't copying till EOF... */
			filesize -= rd;
			if (!filesize) {
				/* 'size' bytes copied - all done */
				status = 0;
				break;
			}
		}
	}
 out:

#if CONFIG_FEATURE_COPYBUF_KB > 4
	if (buffer_size != 4 * 1024)
		munmap(buffer, buffer_size);
#endif
	return status ? -1 : total;
}
#endif

/*Start of MNT 2008-10-13 14:36 for ���䳬ʱ��� by z65940*/
static void transfer_timeout(void)
{
    //fprintf(stderr, "g_TimeoutCnt: %d\n", g_TimeoutCnt);

    if (g_TimeoutCnt < 0)
    {
        alarm(1);
        return;
    }
    else if (g_TimeoutCnt > 0)
    {
        g_TimeoutCnt -= 1;
        alarm(1);
        return;
    }

    // Timeout
    xfunc_error_retval = ATP_TRANS_FILE_ERR;
    bb_error_msg_and_die("Transfer timeout!\n");
    exit(ATP_TRANS_TIMEOUT);
}

// Setup signals
void atp_setup_alarm()
{
    struct sigaction sa;

    memset(&sa, 0, sizeof(sa));
    sa.sa_flags = SA_RESTART;

    //sa.sa_handler = (void (*)(int)) finish_detection;
    //sigaction(SIGINT, &sa, NULL);

    sa.sa_handler = (void (*)(int))transfer_timeout;
    sigaction(SIGALRM, &sa, NULL);
    alarm(1);
}

off_t atp_copy_fd_with_timeout(int src_fd, int dst_fd, off_t size)
{
	int status = -1;
	off_t total = 0;
#if CONFIG_FEATURE_COPYBUF_KB <= 4
	char buffer[CONFIG_FEATURE_COPYBUF_KB * 1024];
	enum { buffer_size = sizeof(buffer) };
#else
	char *buffer;
	int buffer_size;

	/* We want page-aligned buffer, just in case kernel is clever
	 * and can do page-aligned io more efficiently */
	buffer = mmap(NULL, CONFIG_FEATURE_COPYBUF_KB * 1024,
			PROT_READ | PROT_WRITE,
			MAP_PRIVATE | MAP_ANON,
			/* ignored: */ -1, 0);
	buffer_size = CONFIG_FEATURE_COPYBUF_KB * 1024;
	if (buffer == MAP_FAILED) {
		buffer = alloca(4 * 1024);
		buffer_size = 4 * 1024;
	}
#endif

	if (src_fd < 0)
		goto out;

	if (!size) {
		size = buffer_size;
		status = 1; /* copy until eof */
	}

	while (1) {
		ssize_t rd;

        g_TimeoutCnt = ATP_PACK_TIMEOUT_D;
		rd = safe_read(src_fd, buffer, size > buffer_size ? buffer_size : size);
        g_TimeoutCnt = -1;

		if (!rd) { /* eof - all done */
			status = 0;
			break;
		}
		if (rd < 0) {
			bb_perror_msg(bb_msg_read_error);
			break;
		}
		/* dst_fd == -1 is a fake, else... */
		if (dst_fd >= 0) {
            g_TimeoutCnt = ATP_PACK_TIMEOUT_D;  // ����ÿ�����45��
			ssize_t wr = full_write(dst_fd, buffer, rd);
            g_TimeoutCnt = -1;
			if (wr < rd) {
				bb_perror_msg(bb_msg_write_error);
				break;
			}
		}
		total += rd;
		if (status < 0) { /* if we aren't copying till EOF... */
			size -= rd;
			if (!size) {
				/* 'size' bytes copied - all done */
				status = 0;
				break;
			}
		}
	}
 out:

#if CONFIG_FEATURE_COPYBUF_KB > 4
	if (buffer_size != 4 * 1024)
		munmap(buffer, buffer_size);
#endif
	return status ? -1 : total;
}

/*End of MNT 2008-10-13 14:36 for by z65940*/

