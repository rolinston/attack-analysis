/* This is a generated file, don't edit */
const char applet_names[] ALIGN1 = "" 

"[" "\0"
"[[" "\0"
"arp" "\0"
"ash" "\0"
"cat" "\0"
"chmod" "\0"
"chown" "\0"
"cp" "\0"
"date" "\0"
"echo" "\0"
"ftpget" "\0"
"ftpput" "\0"
"halt" "\0"
"ifconfig" "\0"
"init" "\0"
"insmod" "\0"
"kill" "\0"
"killall" "\0"
"linuxrc" "\0"
"ln" "\0"
"logger" "\0"
"ls" "\0"
"mcast" "\0"
"mkdir" "\0"
"mknod" "\0"
"mount" "\0"
"mv" "\0"
"netstat" "\0"
"ping" "\0"
"poweroff" "\0"
"ps" "\0"
"pwd" "\0"
"reboot" "\0"
"rm" "\0"
"rmmod" "\0"
"route" "\0"
"sh" "\0"
"sleep" "\0"
"smuxctl" "\0"
"test" "\0"
"tftp" "\0"
"tftpd" "\0"
"top" "\0"
"traceroute" "\0"
"tty" "\0"
"umount" "\0"
"vconfig" "\0"
"vi" "\0"
"wget" "\0"
"zcip" "\0"
;
int (*const applet_main[])(int argc, char **argv) = {
test_main,
test_main,
arp_main,
ash_main,
cat_main,
chmod_main,
chown_main,
cp_main,
date_main,
echo_main,
ftpget_main,
ftpget_main,
halt_main,
ifconfig_main,
init_main,
insmod_main,
kill_main,
kill_main,
init_main,
ln_main,
logger_main,
ls_main,
mcast_main,
mkdir_main,
mknod_main,
mount_main,
mv_main,
netstat_main,
ping_main,
halt_main,
ps_main,
pwd_main,
halt_main,
rm_main,
rmmod_main,
route_main,
ash_main,
sleep_main,
smuxctl_main,
test_main,
tftp_main,
tftpd_main,
top_main,
traceroute_main,
tty_main,
umount_main,
vconfig_main,
vi_main,
wget_main,
zcip_main,
};
const uint16_t applet_nameofs[] ALIGN2 = {
0x0000,
0x0002,
0x0005,
0x0009,
0x000d,
0x0011,
0x0017,
0x001d,
0x0020,
0x0025,
0x002a,
0x0031,
0x0038,
0x003d,
0x0046,
0x004b,
0x0052,
0x0057,
0x005f,
0x0067,
0x006a,
0x0071,
0x0074,
0x007a,
0x0080,
0x0086,
0x008c,
0x008f,
0x0097,
0x009c,
0x00a5,
0x00a8,
0x00ac,
0x00b3,
0x00b6,
0x00bc,
0x00c2,
0x00c5,
0x00cb,
0x00d3,
0x00d8,
0x00dd,
0x00e3,
0x00e7,
0x00f2,
0x00f6,
0x00fd,
0x0105,
0x0108,
0x010d,
};
const uint8_t applet_install_loc[] ALIGN1 = {
0x33,
0x12,
0x11,
0x11,
0x11,
0x33,
0x22,
0x22,
0x31,
0x10,
0x13,
0x13,
0x11,
0x11,
0x21,
0x11,
0x12,
0x22,
0x11,
0x32,
0x33,
0x33,
0x13,
0x12,
0x23,
};
